<?php
declare(strict_types=1);

final class Updater
{
    private string $currentVersion;
    private string $updateBaseUrl = 'https://updates.peceme.org/cms/';
    private string $baseDir;

    public function __construct(string $currentVersion)
    {
        $this->currentVersion = trim($currentVersion);
        $this->baseDir = dirname(__DIR__);
    }

    public function getCurrentVersion(): string 
    { 
        return $this->currentVersion; 
    }

    public function getManifest(): ?array
    {
        $json = $this->httpGet($this->updateBaseUrl . 'latest.json', 15);
        if (!$json) return null;
        try {
            $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
            return is_array($data) ? $data : null;
        } catch (Throwable $e) {
            return null;
        }
    }

    public function getNewestAvailable(): ?string
    {
        $manifest = $this->getManifest();
        $latest = trim((string)($manifest['latest'] ?? ''));
        if (preg_match('/^\d+(?:\.\d+){1,3}$/', $latest) && version_compare($latest, $this->currentVersion, '>')) {
            return $latest;
        }
        return null;
    }

    public function installVersion(string $version): array
    {
        $version = trim($version);
        $manifest = $this->getManifest();
        $latest = trim((string)($manifest['latest'] ?? ''));

        if ($version !== $latest || version_compare($version, $this->currentVersion, '<=')) {
            return ['success' => false, 'message' => 'Neplatná nebo starší verze pro instalaci.'];
        }

        return $this->install($this->updateBaseUrl . rawurlencode($version) . '.zip', $version);
    }

    public function update(): array
    {
        $newVersion = $this->getNewestAvailable();
        if (!$newVersion) {
            return ['success' => false, 'updated' => false, 'message' => 'Není dostupná žádná novější verze.'];
        }
        $result = $this->installVersion($newVersion);
        $result['updated'] = $result['success'];
        return $result;
    }

    private function install(string $downloadUrl, string $expectedVersion): array
    {
        if (!class_exists('ZipArchive')) {
            return ['success' => false, 'message' => 'Na serveru chybí rozšíření ZipArchive.'];
        }

        $work = $this->baseDir . '/.scriptcms_update_' . bin2hex(random_bytes(8));
        $zipFile = $work . '/update.zip';
        $extractDir = $work . '/extract';
        $backupDir = $work . '/backup';
        $createdTargets = [];

        try {
            foreach ([$work, $extractDir, $backupDir] as $dir) {
                if (!mkdir($dir, 0755, true) && !is_dir($dir)) {
                    throw new RuntimeException('Nelze vytvořit dočasnou složku.');
                }
            }

            $zipData = $this->httpGet($downloadUrl, 180);
            if (!$zipData || strlen($zipData) < 100 || file_put_contents($zipFile, $zipData, LOCK_EX) === false) {
                throw new RuntimeException('Aktualizační ZIP se nepodařilo stáhnout nebo uložit.');
            }

            $zip = new ZipArchive();
            if ($zip->open($zipFile) !== true) throw new RuntimeException('Neplatný ZIP archiv.');

            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = str_replace('\\', '/', (string)$zip->getNameIndex($i));
                if (str_contains($name, ' ') || preg_match('#(^|/)\.\.?(/|$)#', $name)) {
                    throw new RuntimeException('ZIP obsahuje nebezpečnou cestu.');
                }
            }

            if (!$zip->extractTo($extractDir)) {
                $zip->close();
                throw new RuntimeException('ZIP se nepodařilo rozbalit.');
            }
            $zip->close();

            $entries = array_values(array_diff(scandir($extractDir), ['.', '..']));
            $packageRoot = (count($entries) === 1 && is_dir($extractDir . '/' . $entries) && is_file($extractDir . '/' . $entries . '/core/version.php'))
                ? $extractDir . '/' . $entries 
                : $extractDir;

            $versionFile = $packageRoot . '/core/version.php';
            $content = @file_get_contents($versionFile) ?: '';
            preg_match("/SCRIPTCMS_VERSION\s*=\s*['\"]([^'\"]+)['\"]/", $content, $matches);
            $newVersion = trim($matches[1] ?? '');

            if (version_compare($newVersion, $this->currentVersion, '<=') || version_compare($newVersion, $expectedVersion, '!=')) {
                throw new RuntimeException('Verze uvnitř ZIPu neodpovídá manifestu nebo je starší.');
            }

            $files = [];
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($packageRoot, FilesystemIterator::SKIP_DOTS));
            foreach ($iterator as $file) {
                if (!$file->isFile()) continue;
                $relative = ltrim(str_replace('\\', '/', substr($file->getPathname(), strlen($packageRoot))), '/');
                
                if (preg_match('#^(config/users\.json|config/config\.json|install/installed\.lock|content/pages/|content/uploads/|content/media/|\.scriptcms_update/)#', $relative)) {
                    continue;
                }
                $files[] = $relative;
            }

            if (!in_array('core/version.php', $files, true)) {
                throw new RuntimeException('Balíček neobsahuje core/version.php.');
            }

            foreach ($files as $relative) {
                $target = $this->baseDir . '/' . $relative;
                if (!is_file($target)) continue;

                $backup = $backupDir . '/' . $relative;
                if (!is_dir(dirname($backup))) mkdir(dirname($backup), 0755, true);
                if (!copy($target, $backup)) throw new RuntimeException('Nelze zálohovat: ' . $relative);
            }

            foreach ($files as $relative) {
                $source = $packageRoot . '/' . $relative;
                $target = $this->baseDir . '/' . $relative;

                if (!is_dir(dirname($target))) mkdir(dirname($target), 0755, true);
                $wasExisting = is_file($target);

                if (!copy($source, $target)) throw new RuntimeException('Nelze zapsat: ' . $relative);
                if (!$wasExisting) $createdTargets[] = $target;

                if (!hash_equals(hash_file('sha256', $source) ?: '1', hash_file('sha256', $target) ?: '2')) {
                    throw new RuntimeException('Ověření SHA-256 selhalo u: ' . $relative);
                }
            }

            clearstatcache(true, $this->baseDir . '/core/version.php');
            $checkContent = @file_get_contents($this->baseDir . '/core/version.php') ?: '';
            preg_match("/SCRIPTCMS_VERSION\s*=\s*['\"]([^'\"]+)['\"]/", $checkContent, $checkMatches);
            
            if (trim($checkMatches[1] ?? '') !== $newVersion) {
                throw new RuntimeException('Po aktualizaci nebyla ověřena správná verze.');
            }

            $this->cleanup($work);
            return ['success' => true, 'updated' => true, 'version' => $newVersion, 'message' => 'ScriptCMS ™ úspěšně aktualizováno na ' . $newVersion . '.'];

        } catch (Throwable $e) {
            if (is_dir($backupDir)) {
                $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($backupDir, FilesystemIterator::SKIP_DOTS));
                foreach ($iterator as $file) {
                    if ($file->isFile()) {
                        $relative = ltrim(str_replace('\\', '/', substr($file->getPathname(), strlen($backupDir))), '/');
                        $target = $this->baseDir . '/' . $relative;
                        if (!is_dir(dirname($target))) mkdir(dirname($target), 0755, true);
                        @copy($file->getPathname(), $target);
                    }
                }
            }
            foreach ($createdTargets as $target) {
                if (is_file($target)) @unlink($target);
            }
            $this->cleanup($work);
            return ['success' => false, 'updated' => false, 'message' => 'Aktualizace selhala: ' . $e->getMessage()];
        }
    }

    private function cleanup(string $directory): void
    {
        if (!is_dir($directory)) return;
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($iterator as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($directory);
    }

    private function httpGet(string $url, int $timeout): string|false
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
                CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => $timeout, CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_USERAGENT => 'ScriptCMS-Updater'
            ]);
            $data = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            return ($data !== false && $status >= 200 && $status < 300) ? $data : false;
        }

        return @file_get_contents($url, false, stream_context_create([
            'http' => ['method' => 'GET', 'timeout' => $timeout, 'follow_location' => 1, 'max_redirects' => 5, 'header' => "User-Agent: ScriptCMS-Updater\r\n"],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]
        ]));
    }
}

