<?php
class Auth {
    private string $usersFile;

    public function __construct(string $usersFile) {
        $this->usersFile = $usersFile;
        
        if (session_status() === PHP_SESSION_NONE) {
            // Bezpečné nastavení session cookies
            session_set_cookie_params([
                'lifetime' => 0,
                'path' => '/',
                'domain' => '',
                'secure' => isset($_SERVER['HTTPS']), // Pouze přes HTTPS pokud je dostupné
                'httponly' => true,                   // Nedostupné pro JavaScript (ochrana před XSS)
                'samesite' => 'Lax'                   // Ochrana před CSRF
            ]);
            session_start();
        }
    }

    public function login(string $username, string $password): bool {
        if (!file_exists($this->usersFile)) {
            return false;
        }

        $users = json_decode(file_get_contents($this->usersFile), true) ?? [];

        if (isset($users[$username]) && password_verify($password, $users[$username]['password'])) {
            // Zamezení Session Fixation
            session_regenerate_id(true);
            
            $_SESSION['user'] = $username;
            $_SESSION['role'] = $users[$username]['role'] ?? 'editor';
            
            // Vygenerujeme nový CSRF token
            $this->generateCsrfToken();
            return true;
        }

        return false;
    }

    public function isLoggedIn(): bool {
        return isset($_SESSION['user']);
    }

    public function logout(): void {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    // CSRF Ochrana
    public function generateCsrfToken(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public function verifyCsrfToken(?string $token): bool {
        if (empty($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}

