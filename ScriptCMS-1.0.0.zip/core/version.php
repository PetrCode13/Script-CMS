<?php
declare(strict_types=1);

define('SCRIPTCMS_VERSION', '1.0.0');
define('SCRIPTCMS_NAME', 'ScriptCMS ™');
