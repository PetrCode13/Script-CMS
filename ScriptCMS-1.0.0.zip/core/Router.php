<?php
class Router {
    private string $contentDir;

    public function __construct(string $contentDir) {
        $this->contentDir = rtrim($contentDir, '/');
    }

    public function getPagePath(): string {
        $route = $_GET['route'] ?? 'index';
        $route = trim($route, '/');
        
        $route = str_replace(['..', "\0"], '', $route);
        if (empty($route)) {
            $route = 'index';
        }

        $filePath = $this->contentDir . '/' . $route . '.md';

        if (file_exists($filePath)) {
            return $filePath;
        }

        return $this->contentDir . '/404.md';
    }
}

