        </main>
        <hr style="border:0;border-top:1px solid var(--border-color);margin-top:30px;margin-bottom:15px;">
        <footer style="text-align:center;color:var(--text-color);opacity:.7;font-size:.9em;">
            <p>&copy; <?= date('Y') ?> ScriptCMS ™</p>
        </footer>
    </div>
</body>
</html>
