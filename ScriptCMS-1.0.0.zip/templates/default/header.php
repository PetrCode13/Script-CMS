<?php
$pagesDir = __DIR__ . '/../../content/pages';
$pageFiles = glob($pagesDir . '/*.md');

// Výchozí motiv, pokud není nastaven v config.json
$theme = $theme ?? 'dark-blue';
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($siteTitle ?? 'Můj web'); ?></title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <style>
        /* CSS Proměnné pro barevná témata */
        :root {
            <?php if ($theme === 'dark'): ?>
                /* Tmavý grafit */
                --bg-color: #121824;
                --card-bg: #1e293b;
                --text-color: #f1f5f9;
                --border-color: #334155;
                --link-color: #38bdf8;
                --card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);

            <?php elseif ($theme === 'black'): ?>
                /* Černá / AMOLED Dark */
                --bg-color: #050505;
                --card-bg: #121212;
                --text-color: #f0f0f0;
                --border-color: #2a2a2a;
                --link-color: #4da6ff;
                --card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.8);

            <?php elseif ($theme === 'dark-blue'): ?>
                /* Sytá tmavě modrá (Midnight Navy) */
                --bg-color: #0d1b2a;
                --card-bg: #1b263b;
                --text-color: #f0f4f8;
                --border-color: #415a77;
                --link-color: #48cae4;
                --card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);

            <?php elseif ($theme === 'light-blue'): ?>
                /* Sytá modrá pastelka */
                --bg-color: #dbebe5;
                --card-bg: #ffffff;
                --text-color: #0f2a4a;
                --border-color: #90e0ef;
                --link-color: #0077b6;
                --card-shadow: 0 10px 25px -5px rgba(0, 119, 182, 0.12);

            <?php elseif ($theme === 'red'): ?>
                /* Sytá cihelně červená */
                --bg-color: #fbe8e6;
                --card-bg: #ffffff;
                --text-color: #3b1111;
                --border-color: #f5a399;
                --link-color: #d9381e;
                --card-shadow: 0 10px 25px -5px rgba(217, 56, 30, 0.12);

            <?php elseif ($theme === 'green'): ?>
                /* Sytá šalvějově zelená */
                --bg-color: #e2f0d9;
                --card-bg: #ffffff;
                --text-color: #113013;
                --border-color: #a3d99b;
                --link-color: #2e8b57;
                --card-shadow: 0 10px 25px -5px rgba(46, 139, 87, 0.12);

            <?php elseif ($theme === 'yellow'): ?>
                /* Sytý teplý med / okr */
                --bg-color: #fdf3d8;
                --card-bg: #ffffff;
                --text-color: #3a2e05;
                --border-color: #f7d070;
                --link-color: #d97706;
                --card-shadow: 0 10px 25px -5px rgba(217, 119, 6, 0.12);

            <?php elseif ($theme === 'brown'): ?>
                /* Syté teplé dřevo */
                --bg-color: #f3eae1;
                --card-bg: #ffffff;
                --text-color: #362215;
                --border-color: #d1b8a5;
                --link-color: #8b4513;
                --card-shadow: 0 10px 25px -5px rgba(139, 69, 19, 0.12);

            <?php else: ?>
                /* Světlý výchozí (Light) */
                --bg-color: #f1f5f9;
                --card-bg: #ffffff;
                --text-color: #0f172a;
                --border-color: #cbd5e1;
                --link-color: #0284c7;
                --card-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.08);
            <?php endif; ?>
        }

        body { 
            font-family: system-ui, -apple-system, sans-serif; 
            line-height: 1.6; 
            max-width: 850px; 
            margin: 0 auto; 
            padding: 20px 15px; 
            background-color: var(--bg-color); 
            color: var(--text-color); 
            transition: background-color 0.2s, color 0.2s;
        }

        /* Kontejner ve stylu moderní karty */
        .site-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            padding: 28px;
        }
        
        header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-bottom: 2px solid var(--border-color); 
            padding-bottom: 15px; 
            margin-bottom: 25px; 
            position: relative; 
        }
        header h2 { margin: 0; font-size: 1.5rem; }
        
        a { color: var(--link-color); transition: color 0.15s; }
        a:hover { opacity: 0.85; }

        .nav-links { display: flex; gap: 18px; list-style: none; margin: 0; padding: 0; }
        .nav-links a { text-decoration: none; color: var(--text-color); font-weight: 600; }
        
        .hamburger { display: none; background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-color); }

        /* Kódové bloky v Markdownu uvnitř karty */
        pre, code {
            background-color: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 2px 6px;
        }
        pre code { padding: 0; border: none; }
        pre {
            background-color: #0d1117;
            color: #e6edf3;
            padding: 16px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: ui-monospace, SFMono-Regular, monospace;
            font-size: 0.9em;
        }

        @media (max-width: 600px) {
            .site-card { padding: 18px; }
            .hamburger { display: block; }
            .nav-links { 
                display: none; 
                flex-direction: column; 
                position: absolute; 
                top: 100%; 
                right: 0; 
                background: var(--card-bg); 
                border: 1px solid var(--border-color); 
                border-radius: 8px;
                padding: 12px; 
                width: 180px; 
                box-shadow: var(--card-shadow); 
                z-index: 10;
            }
            .nav-links.active { display: flex; }
        }
    
        /* Stylování obrázků */
        img.img-fluid {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 15px 0;
        }

        /* Stylování tabulek */
        .table-responsive {
            overflow-x: auto;
            margin: 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1rem;
        }
        th, td {
            padding: 10px 14px;
            border: 1px solid var(--border-color);
            text-align: left;
        }
        th {
            background-color: var(--bg-color);
            font-weight: 600;
        }
    </style>
<style id="scriptcms-responsive-images">
/* ScriptCMS responsive image safety */
img { max-width: 100%; height: auto; }
.wysiwyg-editor img, .content img, .article-content img, .post-content img, .page-content img {
    max-width: 100%;
    height: auto;
}
</style>
</head>
<body>
    <div class="site-card">
        <header>
            <h2><a href="/" style="text-decoration:none; color:inherit;"><?php echo htmlspecialchars($siteTitle ?? 'Můj web'); ?></a></h2>
            
            <button class="hamburger" onclick="document.querySelector('.nav-links').classList.toggle('active')">&#9776;</button>
            
            <ul class="nav-links">
                <?php foreach ($pageFiles as $file): 
                    $slug = basename($file, '.md');
                    $label = ($slug === 'index') ? 'Domů' : ucfirst($slug);
                    if ($slug === '404') continue;
                    $url = ($slug === 'index') ? '/' : '/' . $slug;
                ?>
                    <li><a href="<?php echo htmlspecialchars($url); ?>"><?php echo htmlspecialchars($label); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </header>
        <main>

