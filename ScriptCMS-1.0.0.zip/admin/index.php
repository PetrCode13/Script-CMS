<?php
declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);


require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/version.php';
require_once __DIR__ . '/../core/Content.php';
require_once __DIR__ . '/../core/Updater.php';

$auth = new Auth(__DIR__ . '/../config/users.json');

if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$role = $_SESSION['role'] ?? 'editor';
$isAdmin = $role === 'admin';
$csrfToken = $auth->generateCsrfToken();

$pagesDir = __DIR__ . '/../content/pages';
$configFile = __DIR__ . '/../config/config.json';
$usersFile = __DIR__ . '/../config/users.json';

if (!is_dir($pagesDir)) {
    mkdir($pagesDir, 0755, true);
}

$configData = json_decode((string) @file_get_contents($configFile), true) ?: [];
$usersData = json_decode((string) @file_get_contents($usersFile), true) ?: [];
$message = '';
$messageType = 'success';

function saveJson(string $file, array $data): void
{
    file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    );
}

function redirectTo(string $url): never
{
    header('Location: ' . $url);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    $auth->logout();
    redirectTo('login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$auth->verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Neplatný CSRF token.');
    }

    $action = $_POST['form_action'] ?? '';

    if ($action === 'save_page') {
        $filename = basename(trim((string) ($_POST['filename'] ?? '')));
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename) ?? '';

        if ($filename === '' || $filename === '.' || $filename === '..') {
            $message = 'Název stránky není platný.';
            $messageType = 'error';
        } else {
            if (!str_ends_with(strtolower($filename), '.md')) {
                $filename .= '.md';
            }

            $rawHtml = (string) ($_POST['content'] ?? '');
            $rawHtml = preg_replace('/^\s*' . preg_quote(Content::HTML_MARKER, '/') . '\s*/', '', $rawHtml, 1) ?? $rawHtml;
            $cleanHtml = Content::sanitizeHtml($rawHtml);

            if ($cleanHtml === '') {
                $cleanHtml = '<p></p>';
            }

            $saved = Content::HTML_MARKER . "\n" . $cleanHtml;
            $target = $pagesDir . '/' . $filename;

            if (file_put_contents($target, $saved, LOCK_EX) === false) {
                $message = 'Stránku se nepodařilo uložit. Zkontroluj práva zápisu.';
                $messageType = 'error';
            } else {
                redirectTo('index.php?view=content&edit=' . urlencode($filename) . '&saved=1');
            }
        }
    }

    if ($action === 'delete_page') {
        $filename = basename((string) ($_POST['filename'] ?? ''));
        if ($filename === 'index.md' || $filename === '404.md') {
            $message = 'Tuto systémovou stránku nelze smazat.';
            $messageType = 'error';
        } elseif (preg_match('/^[a-zA-Z0-9._-]+\.md$/', $filename) && is_file($pagesDir . '/' . $filename)) {
            unlink($pagesDir . '/' . $filename);
            redirectTo('index.php?view=content&deleted=1');
        } else {
            $message = 'Stránka neexistuje.';
            $messageType = 'error';
        }
    }

    if ($action === 'create_user') {
        if (!$isAdmin) {
            http_response_code(403);
            exit('Přístup odepřen.');
        }

        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $newRole = ($_POST['role'] ?? 'editor') === 'admin' ? 'admin' : 'editor';

        if ($username === '' || $password === '') {
            $message = 'Vyplň uživatelské jméno a heslo.';
            $messageType = 'error';
        } elseif (isset($usersData[$username])) {
            $message = 'Tento uživatel již existuje.';
            $messageType = 'error';
        } else {
            $usersData[$username] = [
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role' => $newRole,
            ];
            saveJson($usersFile, $usersData);
            $message = 'Uživatel byl vytvořen.';
        }
    }

    if ($action === 'delete_user') {
        if (!$isAdmin) {
            http_response_code(403);
            exit('Přístup odepřen.');
        }

        $username = (string) ($_POST['username'] ?? '');
        if ($username === ($_SESSION['user'] ?? '')) {
            $message = 'Aktuálně přihlášeného administrátora nelze smazat.';
            $messageType = 'error';
        } elseif (count($usersData) <= 1) {
            $message = 'Nelze smazat poslední účet.';
            $messageType = 'error';
        } elseif (isset($usersData[$username])) {
            unset($usersData[$username]);
            saveJson($usersFile, $usersData);
            $message = 'Uživatel byl smazán.';
        }
    }

    if ($action === 'save_settings') {
        if (!$isAdmin) {
            http_response_code(403);
            exit('Přístup odepřen.');
        }

        $allowedThemes = ['light', 'dark', 'black', 'dark-blue', 'light-blue', 'red', 'green', 'yellow', 'brown'];
        $theme = (string) ($_POST['theme'] ?? 'light');
        if (!in_array($theme, $allowedThemes, true)) $theme = 'light';

        $configData['site_title'] = trim((string) ($_POST['site_title'] ?? 'ScriptCMS Web')) ?: 'ScriptCMS Web';
        $configData['theme'] = $theme;
        saveJson($configFile, $configData);
        $message = 'Nastavení bylo uloženo.';
    }
}

if (isset($_GET['saved'])) {
    $message = 'Stránka byla úspěšně uložena.';
    $messageType = 'success';
}
if (isset($_GET['deleted'])) {
    $message = 'Stránka byla smazána.';
    $messageType = 'success';
}

$files = glob($pagesDir . '/*.md') ?: [];
usort($files, static fn(string $a, string $b): int => strcasecmp(basename($a), basename($b)));

$view = (string) ($_GET['view'] ?? 'dashboard');
$allowedViews = ['dashboard', 'content', 'users', 'settings'];
if ($view === 'updates') {
    redirectTo('update.php');
}
if (!in_array($view, $allowedViews, true)) $view = 'dashboard';

$selectedFile = basename((string) ($_GET['edit'] ?? 'index.md'));
if (!preg_match('/^[a-zA-Z0-9._-]+\.md$/', $selectedFile)) $selectedFile = 'index.md';

$fileContent = is_file($pagesDir . '/' . $selectedFile)
    ? (string) file_get_contents($pagesDir . '/' . $selectedFile)
    : '';

if (isset($_GET['new'])) {
    $selectedFile = 'nova-stranka.md';
    $fileContent = Content::HTML_MARKER . "\n<h1>Nová stránka</h1><p>Začněte psát obsah stránky.</p>";
}

$editorHtml = Content::toEditorHtml($fileContent);

$updateVersion = null;
if ($isAdmin) {
    $cacheTime = (int) ($_SESSION['scriptcms_update_check_time'] ?? 0);
    if (time() - $cacheTime > 300) {
        $updater = new Updater(SCRIPTCMS_VERSION);
        $_SESSION['scriptcms_new_version'] = $updater->getNewestAvailable();
        $_SESSION['scriptcms_update_check_time'] = time();
    }
    $updateVersion = $_SESSION['scriptcms_new_version'] ?? null;
}

$configTheme = $configData['theme'] ?? 'light';
$siteTitle = $configData['site_title'] ?? 'ScriptCMS Web';
?>
<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ScriptCMS ™ — Administrace</title>
<style>
:root{
 --bg:#f4f7fb;--card:#fff;--text:#122033;--muted:#64748b;--border:#dbe3ee;
 --primary:#0878c9;--primary2:#075b9a;--success:#16803c;--danger:#c62828;
 --shadow:0 8px 28px rgba(15,23,42,.07);--radius:14px
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
a{color:inherit}
.admin{min-height:100vh}
.topbar{height:68px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 22px;gap:18px;position:sticky;top:0;z-index:50;box-shadow:0 2px 12px rgba(15,23,42,.04)}
.brand{font-size:1.1rem;font-weight:800;color:var(--primary);white-space:nowrap}
.version{font-size:.78rem;color:var(--muted);font-weight:600}
.menu{display:flex;align-items:center;gap:5px;margin-left:auto}
.menu a{padding:9px 11px;border-radius:9px;text-decoration:none;font-weight:650;font-size:.93rem}
.menu a:hover,.menu a.active{background:#edf6fd;color:var(--primary)}
.menu .logout{color:var(--danger)}
.hamburger{display:none;margin-left:auto;background:transparent;border:1px solid var(--border);border-radius:9px;font-size:1.35rem;padding:7px 11px;cursor:pointer}
.shell{max-width:1250px;margin:0 auto;padding:24px}
.page-head{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:20px}
.page-head h1{margin:0 0 5px;font-size:1.65rem}
.page-head p{margin:0;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px}
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);padding:20px;margin-bottom:18px}
.stat{padding:18px}.stat strong{display:block;font-size:1.8rem;margin-top:4px}.stat span{color:var(--muted);font-size:.88rem}
.notice{border:1px solid #b9dcf7;background:#eef8ff;color:#0b568a;border-radius:12px;padding:16px 18px;display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:18px}
.notice strong{display:block;margin-bottom:3px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:9px;padding:10px 14px;background:var(--primary);color:#fff;text-decoration:none;font-weight:700;cursor:pointer}
.btn:hover{background:var(--primary2)}
.btn.success{background:var(--success)}.btn.danger{background:var(--danger)}.btn.secondary{background:#e9eff5;color:var(--text)}
.btn.full{width:100%}
.layout{display:grid;grid-template-columns:300px minmax(0,1fr);gap:18px}
.card h2,.card h3{margin:0 0 14px}.muted{color:var(--muted)}
input,select{font:inherit;width:100%;border:1px solid var(--border);border-radius:9px;padding:10px 11px;margin:6px 0 12px;background:#fff;color:var(--text)}
label{font-size:.9rem;font-weight:700}
.page-list{list-style:none;padding:0;margin:12px 0 0}.page-list li{display:flex;align-items:center;gap:6px;margin:4px 0}
.page-link{flex:1;text-decoration:none;padding:9px;border-radius:8px;word-break:break-word}.page-link:hover,.page-link.active{background:#edf6fd;color:var(--primary);font-weight:700}
.delete-form{margin:0}.delete-btn{background:#fff1f1;color:var(--danger);border:0;border-radius:7px;padding:7px 9px;cursor:pointer;font-weight:700}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px 9px;border-bottom:1px solid var(--border)}th{font-size:.8rem;color:var(--muted);text-transform:uppercase}
.msg{padding:13px 15px;border-radius:10px;margin-bottom:18px;background:#ecfdf3;color:#166534;border:1px solid #bbf7d0;display:flex;justify-content:space-between;gap:12px}.msg.error{background:#fff1f2;color:#9f1239;border-color:#fecdd3}
.close{border:0;background:transparent;font-size:1.2rem;cursor:pointer;color:inherit}
.editor{border:1px solid var(--border);border-radius:12px;overflow:hidden;background:#fff}
.toolbar{display:flex;flex-wrap:wrap;gap:6px;padding:9px;background:#f7f9fc;border-bottom:1px solid var(--border);position:sticky;top:68px;z-index:20}
.tool{border:1px solid var(--border);background:#fff;border-radius:7px;padding:7px 9px;cursor:pointer;font-weight:700;color:var(--text)}.tool:hover{background:#eaf2f8}
.separator{width:1px;background:var(--border);margin:0 2px}
.editor-area{min-height:520px;height:auto;overflow-y:hidden;padding:22px;outline:none;line-height:1.65;font-size:16px}
.editor-area:focus{box-shadow:inset 0 0 0 2px rgba(8,120,201,.08)}
.editor-area img{max-width:100%;height:auto}.editor-area table{margin:15px 0}.editor-area th,.editor-area td{border:1px solid var(--border);padding:8px}
.editor-area:empty:before{content:"Začněte psát…";color:#94a3b8}
.editor-actions{display:flex;justify-content:space-between;gap:10px;margin-top:13px}
.help{font-size:.86rem;color:var(--muted);margin-top:10px}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.layout{grid-template-columns:1fr}}
@media(max-width:720px){
 .topbar{padding:0 14px}.hamburger{display:block}.menu{display:none;position:absolute;top:68px;left:10px;right:10px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:8px;box-shadow:var(--shadow);flex-direction:column;align-items:stretch}.menu.open{display:flex}.menu a{margin:1px 0}
 .shell{padding:15px}.grid{grid-template-columns:1fr 1fr}.page-head{flex-direction:column}.toolbar{top:68px}.editor-area{min-height:420px;padding:15px}
}
@media(max-width:430px){.grid{grid-template-columns:1fr}.notice{align-items:flex-start;flex-direction:column}.editor-actions{flex-direction:column}.btn{width:100%}}
</style>
<style id="scriptcms-responsive-images">
/* ScriptCMS responsive image safety */
img { max-width: 100%; height: auto; }
.wysiwyg-editor img, .content img, .article-content img, .post-content img, .page-content img {
    max-width: 100%;
    height: auto;
}
</style>
</head>
<body>
<div class="admin">
<header class="topbar">
  <a class="brand" href="index.php?view=dashboard" style="text-decoration:none">ScriptCMS ™</a>
  <span class="version">v<?= htmlspecialchars(SCRIPTCMS_VERSION) ?></span>
  <button class="hamburger" type="button" id="menuButton" aria-label="Otevřít menu" aria-expanded="false">☰</button>
  <nav class="menu" id="adminMenu">
    <a href="index.php?view=dashboard" class="<?= $view==='dashboard'?'active':'' ?>">Přehled</a>
    <a href="index.php?view=content" class="<?= $view==='content'?'active':'' ?>">Obsah</a>
    <?php if ($isAdmin): ?>
      <a href="index.php?view=users" class="<?= $view==='users'?'active':'' ?>">Uživatelé</a>
      <a href="index.php?view=settings" class="<?= $view==='settings'?'active':'' ?>">Nastavení</a>
      <a href="update.php" class="<?= $view==='updates'?'active':'' ?>">Aktualizace<?= $updateVersion ? ' •' : '' ?></a>
    <?php endif; ?>
    <a class="logout" href="index.php?action=logout">Odhlásit se</a>
  </nav>
</header>

<main class="shell">
<?php if ($message): ?>
<div class="msg <?= $messageType==='error'?'error':'' ?>"><span><?= htmlspecialchars($message) ?></span><button class="close" type="button" onclick="this.parentElement.remove()">×</button></div>
<?php endif; ?>

<?php if ($view==='dashboard'): ?>
  <div class="page-head">
    <div><h1>Přehled</h1><p>Vítej, <?= htmlspecialchars((string)($_SESSION['user'] ?? 'uživateli')) ?>.</p></div>
    <a class="btn" href="index.php?view=content&new=1">＋ Nová stránka</a>
  </div>

  <?php if ($isAdmin && $updateVersion): ?>
  <div class="notice">
    <div><strong>Je dostupná nová verze ScriptCMS ™: v<?= htmlspecialchars($updateVersion) ?></strong><span>Aktuálně používáš v<?= htmlspecialchars(SCRIPTCMS_VERSION) ?>.</span></div>
    <a class="btn success" href="update.php">Zobrazit aktualizaci</a>
  </div>
  <?php endif; ?>

  <div class="grid">
    <div class="card stat"><span>Verze systému</span><strong><?= htmlspecialchars(SCRIPTCMS_VERSION) ?></strong></div>
    <div class="card stat"><span>Stránek</span><strong><?= count($files) ?></strong></div>
    <div class="card stat"><span>Uživatelů</span><strong><?= count($usersData) ?></strong></div>
    <div class="card stat"><span>Práva</span><strong><?= $isAdmin?'Admin':'Editor' ?></strong></div>
  </div>

  <div class="card">
    <h2>Rychlé akce</h2>
    <p class="muted">Spravuj obsah webu a systém z jednoho místa.</p>
    <div style="display:flex;flex-wrap:wrap;gap:9px">
      <a class="btn" href="index.php?view=content">Upravit obsah</a>
      <?php if ($isAdmin): ?><a class="btn secondary" href="index.php?view=settings">Nastavení webu</a><a class="btn secondary" href="index.php?view=users">Správa uživatelů</a><?php endif; ?>
    </div>
  </div>

<?php elseif ($view==='content'): ?>
  <div class="page-head">
    <div><h1>Obsah webu</h1><p>Vizuální WYSIWYG editor — bez psaní Markdownu.</p></div>
    <a class="btn" href="index.php?view=content&new=1">＋ Nová stránka</a>
  </div>
  <div class="layout">
    <aside>
      <div class="card">
        <h3>Stránky</h3>
        <ul class="page-list">
        <?php foreach ($files as $file): $name=basename($file); ?>
          <li>
            <a class="page-link <?= $name===$selectedFile && !isset($_GET['new'])?'active':'' ?>" href="index.php?view=content&edit=<?= urlencode($name) ?>"><?= htmlspecialchars($name) ?></a>
            <?php if (!in_array($name,['index.md','404.md'],true)): ?>
              <form class="delete-form" method="post" onsubmit="return confirm('Opravdu chcete tuto stránku smazat?')">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="form_action" value="delete_page">
                <input type="hidden" name="filename" value="<?= htmlspecialchars($name) ?>">
                <button class="delete-btn" title="Smazat" type="submit">×</button>
              </form>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
        </ul>
      </div>
    </aside>
    <section>
      <div class="card">
        <h2><?= isset($_GET['new']) ? 'Nová stránka' : 'Upravit: '.htmlspecialchars($selectedFile) ?></h2>
        <form method="post" id="pageForm">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
          <input type="hidden" name="form_action" value="save_page">
          <label for="filename">Název souboru</label>
          <input id="filename" type="text" name="filename" value="<?= htmlspecialchars($selectedFile) ?>" required>
          <label>Obsah stránky</label>
          <div class="editor">
            <div class="toolbar" role="toolbar" aria-label="Editor">
              <button class="tool" type="button" data-cmd="bold" title="Tučně"><b>B</b></button>
              <button class="tool" type="button" data-cmd="italic" title="Kurzíva"><i>I</i></button>
              <button class="tool" type="button" data-cmd="underline" title="Podtržení"><u>U</u></button>
              <span class="separator"></span>
              <button class="tool" type="button" data-block="h1">H1</button>
              <button class="tool" type="button" data-block="h2">H2</button>
              <button class="tool" type="button" data-block="h3">H3</button>
              <button class="tool" type="button" data-block="p">P</button>
              <span class="separator"></span>
              <button class="tool" type="button" data-cmd="insertUnorderedList">• Seznam</button>
              <button class="tool" type="button" data-cmd="insertOrderedList">1. Seznam</button>
              <button class="tool" type="button" data-cmd="formatBlock" data-value="blockquote">❝ Citace</button>
              <span class="separator"></span>
              <button class="tool" type="button" id="linkBtn">🔗 Odkaz</button>
              <button class="tool" type="button" id="imageBtn">🖼 Obrázek</button>
              <button class="tool" type="button" id="tableBtn">▦ Tabulka</button>
              <button class="tool" type="button" data-cmd="removeFormat">Vyčistit formát</button>
            </div>
            <div id="editor" class="editor-area" contenteditable="true" spellcheck="true"><?= $editorHtml ?></div>
          </div>
          <textarea name="content" id="contentField" hidden></textarea>
          <div class="editor-actions">
            <span class="help">Obsah se bezpečně uloží jako HTML a zachová se i po aktualizaci systému.</span>
            <button class="btn success" type="submit">Uložit stránku</button>
          </div>
        </form>
      </div>
    </section>
  </div>

<?php elseif ($view==='users' && $isAdmin): ?>
  <div class="page-head"><div><h1>Uživatelé</h1><p>Správa administrátorů a editorů.</p></div></div>
  <div class="layout">
    <div class="card">
      <h3>Nový uživatel</h3>
      <form method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
        <input type="hidden" name="form_action" value="create_user">
        <label>Uživatelské jméno</label><input type="text" name="username" required>
        <label>Heslo</label><input type="password" name="password" minlength="6" required>
        <label>Role</label><select name="role"><option value="editor">Editor</option><option value="admin">Administrátor</option></select>
        <button class="btn success full" type="submit">Vytvořit účet</button>
      </form>
    </div>
    <div class="card">
      <h3>Účty</h3>
      <table><thead><tr><th>Uživatel</th><th>Role</th><th>Akce</th></tr></thead><tbody>
      <?php foreach ($usersData as $name=>$data): ?>
        <tr><td><?= htmlspecialchars((string)$name) ?></td><td><?= ($data['role']??'editor')==='admin'?'Administrátor':'Editor' ?></td><td>
        <?php if ($name !== ($_SESSION['user']??'')): ?><form method="post" style="margin:0" onsubmit="return confirm('Opravdu chcete účet smazat?')"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>"><input type="hidden" name="form_action" value="delete_user"><input type="hidden" name="username" value="<?= htmlspecialchars((string)$name) ?>"><button class="btn danger" type="submit">Smazat</button></form><?php else: ?><span class="muted">Přihlášený účet</span><?php endif; ?>
        </td></tr>
      <?php endforeach; ?></tbody></table>
    </div>
  </div>

<?php elseif ($view==='settings' && $isAdmin): ?>
  <div class="page-head"><div><h1>Nastavení</h1><p>Základní nastavení veřejného webu.</p></div></div>
  <div class="card" style="max-width:650px">
    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
      <input type="hidden" name="form_action" value="save_settings">
      <label>Název webu</label><input type="text" name="site_title" value="<?= htmlspecialchars($siteTitle) ?>" required>
      <label>Motiv</label>
      <select name="theme">
        <?php foreach (['light'=>'Světlý','dark'=>'Tmavý','black'=>'Černý AMOLED','dark-blue'=>'Tmavě modrý','light-blue'=>'Světle modrý','red'=>'Červený','green'=>'Zelený','yellow'=>'Žlutý / okr','brown'=>'Hnědý / dřevo'] as $value=>$label): ?>
          <option value="<?= $value ?>" <?= $configTheme===$value?'selected':'' ?>><?= $label ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn success" type="submit">Uložit nastavení</button>
    </form>
  </div>
<?php endif; ?>
</main>
</div>

<script>
const menuButton=document.getElementById('menuButton');
const adminMenu=document.getElementById('adminMenu');
if(menuButton){
  menuButton.addEventListener('click',()=>{const open=adminMenu.classList.toggle('open');menuButton.setAttribute('aria-expanded',open?'true':'false');});
  document.addEventListener('click',e=>{if(window.innerWidth<=720&&!adminMenu.contains(e.target)&&e.target!==menuButton)adminMenu.classList.remove('open');});
}

const editor=document.getElementById('editor');
const form=document.getElementById('pageForm');
const field=document.getElementById('contentField');

if(editor&&form&&field){
  let savedRange=null;
  const saveSelection=()=>{const s=window.getSelection();if(s&&s.rangeCount)savedRange=s.getRangeAt(0).cloneRange();};
  editor.addEventListener('keyup',saveSelection);editor.addEventListener('mouseup',saveSelection);
  editor.addEventListener('input',autoResizeEditor);
  window.addEventListener('load',autoResizeEditor);
  requestAnimationFrame(autoResizeEditor);
  const restore=()=>{if(!savedRange)return;const s=window.getSelection();s.removeAllRanges();s.addRange(savedRange);editor.focus();};
  const autoResizeEditor=()=>{editor.style.height='auto';editor.style.height=Math.max(520,editor.scrollHeight)+'px';};
  const exec=(cmd,val=null)=>{restore();document.execCommand(cmd,false,val);saveSelection();editor.focus();autoResizeEditor();};
  document.querySelectorAll('[data-cmd]').forEach(btn=>btn.addEventListener('click',()=>exec(btn.dataset.cmd,btn.dataset.value||null)));
  document.querySelectorAll('[data-block]').forEach(btn=>btn.addEventListener('click',()=>exec('formatBlock','<'+btn.dataset.block+'>')));
  document.getElementById('linkBtn')?.addEventListener('click',()=>{const url=prompt('URL odkazu:','https://');if(url)exec('createLink',url);});
  document.getElementById('imageBtn')?.addEventListener('click',()=>{const url=prompt('URL obrázku:','https://');if(url)exec('insertImage',url);});
  document.getElementById('tableBtn')?.addEventListener('click',()=>{
    restore();
    const html='<table><thead><tr><th>Hlavička</th><th>Hlavička</th></tr></thead><tbody><tr><td>Text</td><td>Text</td></tr></tbody></table><p></p>';
    document.execCommand('insertHTML',false,html);saveSelection();autoResizeEditor();
  });
  form.addEventListener('submit',()=>{field.value='<!-- ScriptCMS HTML -->\n'+editor.innerHTML;});
}
</script>
</body>
</html>
