<?php
declare(strict_types=1);

require_once __DIR__ . '/core/version.php';
require_once __DIR__ . '/core/Router.php';
require_once __DIR__ . '/core/Content.php';

$configFile = __DIR__ . '/config/config.json';
$configData = file_exists($configFile) ? (json_decode((string) file_get_contents($configFile), true) ?: []) : [];

$siteTitle = $configData['site_title'] ?? 'ScriptCMS Web';
$theme = $configData['theme'] ?? 'light';

$router = new Router(__DIR__ . '/content/pages');
$pagePath = $router->getPagePath();

$content = is_file($pagePath)
    ? (string) file_get_contents($pagePath)
    : "# 404\nStránka nebyla nalezena.";

$contentHtml = Content::render($content);

require __DIR__ . '/templates/default/header.php';
echo $contentHtml;
require __DIR__ . '/templates/default/footer.php';
